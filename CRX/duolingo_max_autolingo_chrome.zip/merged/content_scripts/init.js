const injectScript = (fileName) => {
    let th = document.getElementsByTagName('body')[0];
    let s = document.createElement('script');
    s.setAttribute('type', 'module');
    s.setAttribute('src', `chrome-extension://${chrome.runtime.id}/${fileName}`);
    th.appendChild(s);
}

const send_custom_event = (event_name, data=null) => {
    var event = document.createEvent("CustomEvent");
    event.initCustomEvent(event_name, true, true, {"data": data});
    document.dispatchEvent(event);
}

// Toggle overlay visibility based on autolingo_enabled
const updateOverlayVisibility = (enabled) => {
    if (enabled) {
        document.body.classList.add('autolingo-enabled');
    } else {
        document.body.classList.remove('autolingo-enabled');
    }
};

chrome.storage.local.get('autolingo_enabled', (response) => {
    updateOverlayVisibility(Boolean(response.autolingo_enabled));
});

chrome.storage.onChanged.addListener((changes, area) => {
    if (area === 'local' && 'autolingo_enabled' in changes) {
        updateOverlayVisibility(Boolean(changes.autolingo_enabled.newValue));
    }
});

injectScript("content_scripts/injected.js");

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    switch (message.action) {
        case "solve_challenge":
            send_custom_event("solve_challenge");
            break;
        case "solve_skip_challenge":
            send_custom_event("solve_skip_challenge");
            break;
        case "set_delay":
            send_custom_event("set_delay", message.delay);
            break;
        default:
            console.error(`Unknown message type '${message.action}'`);
    }
});

window.addEventListener("get_extension_id", () => {
    send_custom_event("extension_id", chrome.runtime.id);
    chrome.storage.local.get("autolingo_delay", (response) => {
        const delay = response["autolingo_delay"];
        send_custom_event("set_delay", delay);
    });
});
